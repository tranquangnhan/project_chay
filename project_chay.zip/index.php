<?php
header("location: ''");
?>  