<?php
require_once "../../../system/config.php";
require_once "../../../system/database.php";
require_once "../../models/home.php";
$model = new Model_home;

switch ($_POST['action']) {
    case 'add':
        $array = array();
        $model->storeContact($_POST['name'],$_POST['email'],$_POST['id_contact'],$_POST['message']);
        echo json_encode('1111');

        break;
  
    default:
        # code...
        break;
}
